package projetoStart;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;

public class ExcluiLivro extends JFrame {

	private JPanel contentPane;
	private JTextField txtPagina;
	private JTextField txtTitulo;
	private JTextField txtGenero;
	private JTextField txtAutor;
	private JTextField txtPesquisa;
	private JTextField txtEditora;
	
	BancoDeDados banco = new BancoDeDados();
	String[] retorno = new String[15];
	

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ExcluiLivro frame = new ExcluiLivro();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	
	public ExcluiLivro() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 794, 415);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblTitulo = new JLabel("T�tulo:");
		lblTitulo.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblTitulo.setBounds(149, 120, 65, 30);
		contentPane.add(lblTitulo);
		
		JLabel lblGenero = new JLabel("G�nero:");
		lblGenero.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblGenero.setBounds(149, 163, 65, 30);
		contentPane.add(lblGenero);
		
		JLabel lblAutor = new JLabel("Autor:");
		lblAutor.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblAutor.setBounds(149, 206, 52, 30);
		contentPane.add(lblAutor);
		
		JLabel lblPagina = new JLabel("P�gina:");
		lblPagina.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblPagina.setBounds(149, 249, 65, 30);
		contentPane.add(lblPagina);
		
		txtPagina = new JTextField();
		txtPagina.setFont(new Font("Tahoma", Font.PLAIN, 15));
		txtPagina.setBounds(260, 254, 260, 22);
		contentPane.add(txtPagina);
		txtPagina.setColumns(10);
		
		txtTitulo = new JTextField();
		txtTitulo.setFont(new Font("Tahoma", Font.PLAIN, 15));
		txtTitulo.setBounds(260, 125, 260, 22);
		contentPane.add(txtTitulo);
		txtTitulo.setColumns(10);
		
		txtGenero = new JTextField();
		txtGenero.setFont(new Font("Tahoma", Font.PLAIN, 15));
		txtGenero.setBounds(260, 168, 260, 22);
		contentPane.add(txtGenero);
		txtGenero.setColumns(10);
		
		txtAutor = new JTextField();
		txtAutor.setFont(new Font("Tahoma", Font.PLAIN, 15));
		txtAutor.setBounds(260, 211, 260, 22);
		contentPane.add(txtAutor);
		txtAutor.setColumns(10);
		
		JButton btnPesquisar = new JButton("Pesquisar");
		btnPesquisar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				banco.conectar();
				if (txtPesquisa.getText().trim().equals("")){
					JOptionPane.showMessageDialog(null, "Insira algum valor para a pesquisa!");
				}else if(banco.estaConectado()){
				retorno = banco.buscarLivro(txtPesquisa.getText());
				
					txtTitulo.setText(retorno[1]);
					txtGenero.setText(retorno[3]);
					txtPagina.setText(retorno[2]);
					txtAutor.setText(retorno[4]);
					txtEditora.setText(retorno[6]);
					banco.desconectar();
					
				}
			}
		});
		btnPesquisar.setBounds(154, 56, 130, 50);
		contentPane.add(btnPesquisar);
		
		JButton btnExcluir = new JButton("Excluir Livro");
		btnExcluir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				banco.conectar();
				banco.excluiLivro(txtPesquisa.getText());
				banco.desconectar();
				ExcluiLivro.this.dispose();
			}
		});
		btnExcluir.setBounds(468, 56, 166, 50);
		contentPane.add(btnExcluir);
		
		JLabel lblTopo = new JLabel("Digite o t�tulo ou n�mero de registro do livro:");
		lblTopo.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblTopo.setBounds(12, 13, 500, 30);
		contentPane.add(lblTopo);
		
		txtPesquisa = new JTextField();
		txtPesquisa.setFont(new Font("Tahoma", Font.PLAIN, 15));
		txtPesquisa.setBounds(435, 19, 254, 22);
		contentPane.add(txtPesquisa);
		txtPesquisa.setColumns(10);
		
		JLabel lblEditora = new JLabel("Editora:");
		lblEditora.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblEditora.setBounds(149, 292, 61, 30);
		contentPane.add(lblEditora);
		
		txtEditora = new JTextField();
		txtEditora.setFont(new Font("Tahoma", Font.PLAIN, 15));
		txtEditora.setBounds(260, 297, 260, 22);
		contentPane.add(txtEditora);
		txtEditora.setColumns(10);
	}
}
