package projetoStart;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;

public class ReservarLivro extends Autenticacao {

	private JPanel contentPane;
	private JTextField txtPagina;
	private JTextField txtTitulo;
	private JTextField txtGenero;
	private JTextField txtAutor;
	private JTextField txtPesquisa;
	private JTextField txtEditora;
	
	BancoDeDados banco = new BancoDeDados();
	String[] pesquisa = new String[15];
	private JTextField txtReserva;
	

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ReservarLivro frame = new ReservarLivro();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	
	public ReservarLivro() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 794, 415);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblTitulo = new JLabel("T�tulo:");
		lblTitulo.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblTitulo.setBounds(149, 120, 65, 30);
		contentPane.add(lblTitulo);
		
		JLabel lblGenero = new JLabel("G�nero:");
		lblGenero.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblGenero.setBounds(149, 163, 65, 30);
		contentPane.add(lblGenero);
		
		JLabel lblAutor = new JLabel("Autor:");
		lblAutor.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblAutor.setBounds(149, 206, 52, 30);
		contentPane.add(lblAutor);
		
		JLabel lblPagina = new JLabel("P�gina:");
		lblPagina.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblPagina.setBounds(149, 249, 65, 30);
		contentPane.add(lblPagina);
		
		txtPagina = new JTextField();
		txtPagina.setFont(new Font("Tahoma", Font.PLAIN, 15));
		txtPagina.setBounds(260, 254, 260, 22);
		contentPane.add(txtPagina);
		txtPagina.setColumns(10);
		
		txtTitulo = new JTextField();
		txtTitulo.setFont(new Font("Tahoma", Font.PLAIN, 15));
		txtTitulo.setBounds(260, 125, 260, 22);
		contentPane.add(txtTitulo);
		txtTitulo.setColumns(10);
		
		txtGenero = new JTextField();
		txtGenero.setFont(new Font("Tahoma", Font.PLAIN, 15));
		txtGenero.setBounds(260, 168, 260, 22);
		contentPane.add(txtGenero);
		txtGenero.setColumns(10);
		
		txtAutor = new JTextField();
		txtAutor.setFont(new Font("Tahoma", Font.PLAIN, 15));
		txtAutor.setBounds(260, 211, 260, 22);
		contentPane.add(txtAutor);
		txtAutor.setColumns(10);
		
		JButton btnPesquisar = new JButton("Pesquisar");
		btnPesquisar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				banco.conectar();
				if (txtPesquisa.getText().trim().equals("")){
					JOptionPane.showMessageDialog(null, "Insira algum valor para a pesquisa!");
				}else if(banco.estaConectado()){
				pesquisa = banco.buscarLivro(txtPesquisa.getText());
				
					txtTitulo.setText(pesquisa[1]);
					txtGenero.setText(pesquisa[3]);
					txtPagina.setText(pesquisa[2]);
					txtAutor.setText(pesquisa[4]);
					txtEditora.setText(pesquisa[6]);
					if (Integer.parseInt(pesquisa[7]) == 0 || pesquisa[7] == null){
						txtReserva.setText("Livre");
					}else{
						txtReserva.setText(pesquisa[7]);
					};
					banco.desconectar();
					
				}
			}
		});
		btnPesquisar.setBounds(154, 56, 130, 50);
		contentPane.add(btnPesquisar);
		
		JButton btnSair = new JButton("Sair");
		btnSair.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				ReservarLivro.this.dispose();
				}	
		});
		btnSair.setBounds(559, 56, 130, 50);
		contentPane.add(btnSair);
		
		JLabel lblTopo = new JLabel("Digite o t�tulo ou n�mero de registro do livro:");
		lblTopo.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblTopo.setBounds(12, 13, 500, 30);
		contentPane.add(lblTopo);
		
		txtPesquisa = new JTextField();
		txtPesquisa.setFont(new Font("Tahoma", Font.PLAIN, 15));
		txtPesquisa.setBounds(435, 19, 254, 22);
		contentPane.add(txtPesquisa);
		txtPesquisa.setColumns(10);
		
		JLabel lblEditora = new JLabel("Editora:");
		lblEditora.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblEditora.setBounds(149, 292, 61, 30);
		contentPane.add(lblEditora);
		
		txtEditora = new JTextField();
		txtEditora.setFont(new Font("Tahoma", Font.PLAIN, 15));
		txtEditora.setBounds(260, 297, 260, 22);
		contentPane.add(txtEditora);
		txtEditora.setColumns(10);
		
		JButton btnReservar = new JButton("Reservar");
		btnReservar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			banco.conectar();	
			if(banco.estaConectado()){
				int reservas = Integer.parseInt(pesquisa[5]);
				++reservas;
				int numReservas = Integer.parseInt(retorno[5]);
				++numReservas;
				if((pesquisa[7] == null) || (Integer.parseInt(pesquisa[7]) == 0)){
					if(Integer.parseInt(retorno[11]) == 2){
						
						banco.reservarLivro(Integer.parseInt(txtReserva.getText()), reservas, numReservas, txtPesquisa.getText());
					}else{
						txtReserva.setText(retorno[11]);
						banco.reservarLivro(Integer.parseInt(txtReserva.getText()), reservas, numReservas, txtPesquisa.getText());
						
					}
				}else{
					JOptionPane.showMessageDialog(null, "O livro j� est� reservado! Tente mais tarde.");
				}
			ReservarLivro.this.dispose();
			}banco.desconectar();
			
			}
		});
		btnReservar.setBounds(353, 56, 130, 50);
		contentPane.add(btnReservar);
		
		JLabel lblReservante = new JLabel("Reservante:");
		lblReservante.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblReservante.setBounds(149, 342, 92, 16);
		contentPane.add(lblReservante);
		
		txtReserva = new JTextField();
		txtReserva.setFont(new Font("Tahoma", Font.PLAIN, 15));
		txtReserva.setBounds(260, 340, 260, 22);
		contentPane.add(txtReserva);
		txtReserva.setColumns(10);
	}
}
