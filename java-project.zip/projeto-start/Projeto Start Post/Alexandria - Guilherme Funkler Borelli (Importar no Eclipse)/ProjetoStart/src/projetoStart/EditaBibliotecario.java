package projetoStart;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;

public class EditaBibliotecario extends JFrame {

	private JPanel contentPane;
	private JTextField txtEmail;
	private JTextField txtUsuario;
	private JTextField txtSenha;
	private JTextField txtNome;
	private JTextField txtPesquisa;

	BancoDeDados banco = new BancoDeDados();
	String[] retorno = new String[15];
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					EditaBibliotecario frame = new EditaBibliotecario();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	
	public EditaBibliotecario() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 794, 415);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblUsuario = new JLabel("Usu�rio:");
		lblUsuario.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblUsuario.setBounds(139, 120, 65, 30);
		contentPane.add(lblUsuario);
		
		JLabel lblSenha = new JLabel("Senha:");
		lblSenha.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblSenha.setBounds(150, 180, 54, 30);
		contentPane.add(lblSenha);
		
		JLabel lblNome = new JLabel("Nome:");
		lblNome.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNome.setBounds(152, 240, 52, 30);
		contentPane.add(lblNome);
		
		JLabel lblEmail = new JLabel("Email:");
		lblEmail.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblEmail.setBounds(156, 300, 48, 30);
		contentPane.add(lblEmail);
		
		txtEmail = new JTextField();
		txtEmail.setFont(new Font("Tahoma", Font.PLAIN, 15));
		txtEmail.setBounds(260, 305, 260, 22);
		contentPane.add(txtEmail);
		txtEmail.setColumns(10);
		
		txtUsuario = new JTextField();
		txtUsuario.setFont(new Font("Tahoma", Font.PLAIN, 15));
		txtUsuario.setBounds(260, 125, 260, 22);
		contentPane.add(txtUsuario);
		txtUsuario.setColumns(10);
		
		txtSenha = new JTextField();
		txtSenha.setFont(new Font("Tahoma", Font.PLAIN, 15));
		txtSenha.setBounds(260, 185, 260, 22);
		contentPane.add(txtSenha);
		txtSenha.setColumns(10);
		
		txtNome = new JTextField();
		txtNome.setFont(new Font("Tahoma", Font.PLAIN, 15));
		txtNome.setBounds(260, 245, 260, 22);
		contentPane.add(txtNome);
		txtNome.setColumns(10);
		
		JButton btnPesquisar = new JButton("Pesquisar");
		btnPesquisar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				banco.conectar();
				if (txtPesquisa.getText().trim().equals("")){
					JOptionPane.showMessageDialog(null, "Insira algum valor para a pesquisa!");
				}else if(banco.estaConectado()){
				retorno = banco.buscarContato(txtPesquisa.getText());
				if(Integer.parseInt(retorno[11]) == 2){
				txtUsuario.setText(retorno[1]);
				txtSenha.setText(retorno[2]);
				txtEmail.setText(retorno[3]);
				txtNome.setText(retorno[4]);
				banco.desconectar();
				}else{
					JOptionPane.showMessageDialog(null, "Este usu�rio n�o � um bibliotec�rio!");	
					}
				}
			}
		});
		btnPesquisar.setBounds(154, 56, 130, 50);
		contentPane.add(btnPesquisar);
		
		JButton btnAlterar = new JButton("Salvar Altera��es");
		btnAlterar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				banco.conectar();
				if(banco.estaConectado()){
					if(txtEmail.getText().trim().equals("")){
						JOptionPane.showMessageDialog(null, "Campo Email sem dados!");
					}else if(txtNome.getText().trim().equals("")){
						JOptionPane.showMessageDialog(null, "Campo Nome sem dados!");
					}else if(txtSenha.getText().trim().equals("")){
						JOptionPane.showMessageDialog(null, "Campo Senha sem dados!");
					}else if (txtUsuario.getText().trim().equals("")){
						JOptionPane.showMessageDialog(null, "Campo Usu�rio sem dados!");
					}else{
						banco.editarBibliotecario(txtUsuario.getText(), txtSenha.getText(), txtEmail.getText(), txtNome.getText());
						EditaBibliotecario.this.dispose();
					}
				}else{
					JOptionPane.showMessageDialog(null, "Ocorreu um erro, favor tentar novamente!");
				}
				banco.desconectar();
			}
		});
		btnAlterar.setBounds(468, 56, 142, 50);
		contentPane.add(btnAlterar);
		
		JLabel lblTopo = new JLabel("Digite o nome ou n�mero de registro do bibliotec�rio:");
		lblTopo.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblTopo.setBounds(12, 13, 480, 30);
		contentPane.add(lblTopo);
		
		txtPesquisa = new JTextField();
		txtPesquisa.setFont(new Font("Tahoma", Font.PLAIN, 15));
		txtPesquisa.setBounds(494, 20, 270, 22);
		contentPane.add(txtPesquisa);
		txtPesquisa.setColumns(10);
	}
}
