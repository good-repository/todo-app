package projetoStart;

import java.awt.JobAttributes;
import java.awt.List;
import java.awt.Window;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class BancoDeDados extends JFrame{

	private Connection conn = null;
	private Statement stmt = null;
	private ResultSet rs = null;
	private PreparedStatement ps = null;
	String[] retorno = new String[15];
	boolean isNum = true;
	
	
	
		try{
			Class.forName(driver);
			this.conn = DriverManager.getConnection(servidor, usuario, senha);
			this.stmt = this.conn.createStatement();
		}catch (Exception e){
			System.out.println("Erro: " + e.getMessage());
		}
	}
	
	public boolean estaConectado(){
		if(this.conn != null){
			return true;
		}else{
			return false;
		}
	}
	
	public String[] login (String usuario){
			try{
				Integer.parseInt(usuario);
			}catch(NumberFormatException e){
				isNum = false;
			}
			if (isNum){
		try{
			Integer.parseInt(usuario);
			String query = "SELECT * FROM cadastro WHERE cadastro.idCadastro ='" + usuario + "';";
			stmt = conn.createStatement();
			this.rs = this.stmt.executeQuery(query);
			if(!rs.next()){
				 JOptionPane.showMessageDialog(null, "N�o localizado no cadastro!");}
			else{
				rs.previous();
			while(rs.next()){
				retorno[0] = Integer.toString(rs.getInt("idCadastro"));
				retorno[1] = rs.getString("usuario");
				retorno[2] = rs.getString("senha");
				retorno[3] = rs.getString("email");
				retorno[4] = rs.getString("nome");
				retorno[5] = Integer.toString(rs.getInt("reservas"));
				retorno[6] = rs.getString("telefone");
				retorno[7] = rs.getString("endereco");
				retorno[8] = rs.getString("bairro");
				retorno[9] = rs.getString("cidade");
				retorno[10] = rs.getString("estado");
				retorno[11] = Integer.toString(rs.getInt("tipoUsuario"));
			return retorno;
				}
			}
		}catch(Exception e){
			System.out.println(e.getMessage());
			}
		}else{
			try{
			String query = "SELECT * FROM cadastro WHERE cadastro.usuario ='" + usuario + "';";
			stmt = conn.createStatement();
			this.rs = this.stmt.executeQuery(query);
			if(!rs.next()){
				 JOptionPane.showMessageDialog(null, "N�o localizado no cadastro!");}
			else{
				rs.previous();
			while(rs.next()){
				retorno[0] = Integer.toString(rs.getInt("idCadastro"));
				retorno[1] = rs.getString("usuario");
				retorno[2] = rs.getString("senha");
				retorno[3] = rs.getString("email");
				retorno[4] = rs.getString("nome");
				retorno[5] = Integer.toString(rs.getInt("reservas"));
				retorno[6] = rs.getString("telefone");
				retorno[7] = rs.getString("endereco");
				retorno[8] = rs.getString("bairro");
				retorno[9] = rs.getString("cidade");
				retorno[10] = rs.getString("estado");
				retorno[11] = Integer.toString(rs.getInt("tipoUsuario"));
			return retorno;
				}
			}
		}catch(Exception e){
			System.out.println(e.getMessage());
		}
		return null;
			}
		return null;
	}
	
	public String[] buscarContato(String busca){
		try{
			Integer.parseInt(busca);
		}catch(NumberFormatException e){
			isNum = false;
		}
		if(isNum){
			try{
			Integer.parseInt(busca);
			String query = "SELECT * FROM cadastro WHERE cadastro.idCadastro ='" + busca + "';";
			stmt = conn.createStatement();
			this.rs = this.stmt.executeQuery(query);
			if(!rs.next()){
				 JOptionPane.showMessageDialog(null, "N�o localizado no cadastro!");}
			else{
				rs.previous();
			while(rs.next()){
				retorno[0] = Integer.toString(rs.getInt("idCadastro"));
				retorno[1] = rs.getString("usuario");
				retorno[2] = rs.getString("senha");
				retorno[3] = rs.getString("email");
				retorno[4] = rs.getString("nome");
				retorno[5] = Integer.toString(rs.getInt("reservas"));
				retorno[6] = rs.getString("telefone");
				retorno[7] = rs.getString("endereco");
				retorno[8] = rs.getString("bairro");
				retorno[9] = rs.getString("cidade");
				retorno[10] = rs.getString("estado");
				retorno[11] = Integer.toString(rs.getInt("tipoUsuario"));
				return retorno;
					}
				}
			}catch (Exception e){
			e.printStackTrace();
		}
	}
		else{
		try{
			String query = "SELECT * FROM cadastro WHERE cadastro.nome ='" + busca + "';";
			stmt = conn.createStatement();
			this.rs = this.stmt.executeQuery(query);
			if(!rs.next()){
				 JOptionPane.showMessageDialog(null, "N�o localizado no cadastro!");}
			else{
				rs.previous();
			while(rs.next()){
				retorno[0] = Integer.toString(rs.getInt("idCadastro"));
				retorno[1] = rs.getString("usuario");
				retorno[2] = rs.getString("senha");
				retorno[3] = rs.getString("email");
				retorno[4] = rs.getString("nome");
				retorno[5] = Integer.toString(rs.getInt("reservas"));
				retorno[6] = rs.getString("telefone");
				retorno[7] = rs.getString("endereco");
				retorno[8] = rs.getString("bairro");
				retorno[9] = rs.getString("cidade");
				retorno[10] = rs.getString("estado");
				retorno[11] = Integer.toString(rs.getInt("tipoUsuario"));
				return retorno;
					}
				}
		}catch (Exception e){
			if(retorno[1] == null){
				 JOptionPane.showMessageDialog(null, "N�o localizado no cadastro!");;
			 }
			e.printStackTrace();
			}	
		}
		return null;
	}
	
	public String[] buscarLivro(String busca){
		try{
			Integer.parseInt(busca);
		}catch(NumberFormatException e){
			isNum = false;
		}
		if(isNum){
			try{
			Integer.parseInt(busca);
			String query = "SELECT * FROM livro WHERE livro.idLivro ='" + busca + "';";
			stmt = conn.createStatement();
			this.rs = this.stmt.executeQuery(query);
			if(!rs.next()){
				 JOptionPane.showMessageDialog(null, "N�o localizado no cadastro!");}
			else{
				rs.previous();
			while(rs.next()){
				retorno[0] = Integer.toString(rs.getInt("idLivro"));
				retorno[1] = rs.getString("titulo");
				retorno[2] = rs.getString("paginas");
				retorno[3] = rs.getString("genero");
				retorno[4] = rs.getString("autor");
				retorno[5] = Integer.toString(rs.getInt("reservas"));
				retorno[6] = rs.getString("editora");
				retorno[7] = Integer.toString(rs.getInt("idReserva"));
				retorno[8] = rs.getString("dataReserva");
				retorno[9] = rs.getString("dataDevolver");
				return retorno;
					}
				}
			}catch (Exception e){
			e.printStackTrace();
		}
	}
		else{
		try{
			String query = "SELECT * FROM livro WHERE livro.titulo ='" + busca + "';";
			stmt = conn.createStatement();
			this.rs = this.stmt.executeQuery(query);
			if(!rs.next()){
				 JOptionPane.showMessageDialog(null, "N�o localizado no cadastro!");}
			else{
				rs.previous();
			while(rs.next()){
				retorno[0] = Integer.toString(rs.getInt("idLivro"));
				retorno[1] = rs.getString("titulo");
				retorno[2] = rs.getString("paginas");
				retorno[3] = rs.getString("genero");
				retorno[4] = rs.getString("autor");
				retorno[5] = Integer.toString(rs.getInt("reservas"));
				retorno[6] = rs.getString("editora");
				retorno[7] = Integer.toString(rs.getInt("idReserva"));
				retorno[8] = rs.getString("dataReserva");
				return retorno;
					}
				}
		}catch (Exception e){
			if(retorno[1] == null){
				 JOptionPane.showMessageDialog(null, "N�o localizado no cadastro!");;
			 }
			e.printStackTrace();
			}	
		}
		return null;
	}
	
	public void listarContatos(){
		try{
			String query = "SELECT * FROM cadastro";
			stmt = conn.createStatement();
			this.rs = this.stmt.executeQuery(query);
			while (this.rs.next()){
				System.out.println("ID: "+ this.rs.getInt("idCadastro") +" Nome: " + this.rs.getString("nome"));
			}
			stmt.close();
		}catch(Exception e){
			System.out.println("Erro: " + e.getMessage());
		}
	}
	
	public void inserirAdministrador(String usuario, String senha, String email, String nome){
		try{
			String query = "INSERT INTO cadastro (usuario, senha, email, nome, tipoUsuario) VALUES ('" + usuario + "', '" + email + "', '" + senha + "', '" + nome + "', '" + 1 + "');";
			
			ps = conn.prepareStatement(query, stmt.RETURN_GENERATED_KEYS);
			ps.executeUpdate();
			rs = ps.getGeneratedKeys();
				if (rs.next()){
					final int lasdID = rs.getInt(1);
					JOptionPane.showMessageDialog(null, "O n�mero de matricula gerado foi:  " + lasdID + ". Guarde este n�mero!" );
					JOptionPane.showMessageDialog(null, "Cadastro efetuado com sucesso! Voltando ao menu principal...");
				}
			stmt.close();	
		}catch (Exception e){
			System.out.println("Erro: " + e.getMessage());
		}
		
	}
	
	public void inserirBibliotecario(String usuario, String senha, String email, String nome){
		try{
			String query = "INSERT INTO cadastro (usuario, senha, email, nome, tipoUsuario) VALUES ('" + usuario + "', '" + senha + "', '" + email + "', '" + nome + "', '" + 2 + "');";
			stmt = conn.createStatement();
			ps = conn.prepareStatement(query, stmt.RETURN_GENERATED_KEYS);
			ps.executeUpdate();
			rs = ps.getGeneratedKeys();
				if (rs.next()){
					final int lasdID = rs.getInt(1);
					JOptionPane.showMessageDialog(null, "O n�mero de matricula gerado foi:  " + lasdID + ". Guarde este n�mero!" );
					JOptionPane.showMessageDialog(null, "Cadastro efetuado com sucesso! Voltando ao menu principal...");
				}
			stmt.close();
		}catch (Exception e){
			System.out.println("Erro: " + e.getMessage());
		}
		
	}
	
	public void inserirAssociado(String usuario, String senha, String email, String nome, int reservas, String telefone, String endereco, String bairro, String cidade, String estado){
		try{
			String query = "INSERT INTO cadastro (usuario, senha, email, nome, reservas, telefone, endereco, bairro, cidade, estado, tipoUsuario) VALUES ('" + usuario + "', '" + senha + "', '" + email + "', '" + nome + "', '" + reservas + "', '" + telefone + "', '" + endereco + "', '" + bairro + "', '" + cidade + "', '" + estado + "', '" + 3 + "');";
			stmt = conn.createStatement();
			ps = conn.prepareStatement(query, stmt.RETURN_GENERATED_KEYS);
			ps.executeUpdate();
			rs = ps.getGeneratedKeys();
				if (rs.next()){
					final int lasdID = rs.getInt(1);
					JOptionPane.showMessageDialog(null, "O n�mero de matricula gerado foi:  " + lasdID + ". Guarde este n�mero!" );
					JOptionPane.showMessageDialog(null, "Cadastro efetuado com sucesso! Voltando ao menu principal...");
				}
			stmt.close();
		}catch (Exception e){
			System.out.println("Erro: " + e.getMessage());
		}
		
	}
	
	public void inserirLivro(String titulo, int paginas, String genero, String autor, String editora){
		try{
			String query = "INSERT INTO livro (titulo, paginas, genero, autor, editora, reservas) VALUES ('" + titulo + "', '" + paginas + "', '" + genero + "', '" + autor + "', '" + editora + "', '" + 0 + "');";
			this.stmt.executeUpdate(query);
			JOptionPane.showMessageDialog(null, "Livro cadastrado com sucesso! Voltando ao menu principal...");
			stmt.close();
		}catch (Exception e){
			System.out.println("Erro: " + e.getMessage());
		}
		
	}
	
	public void editarAdministrador (String usuario, String senha, String email, String nome){
		try{
			String query = "UPDATE cadastro SET senha = '" + senha + "', email = '" + email + "', nome = '" + nome + "' WHERE usuario = '" + usuario + "'; ";
			stmt = conn.createStatement();
			this.stmt.executeUpdate(query);
			JOptionPane.showMessageDialog(null, "Editado com sucesso! Voltando ao menu principal...");
			stmt.close();
		}catch (Exception e){
			System.out.println("Erro: " + e.getMessage());
		}
	}
	
	public void editarBibliotecario (String usuario, String senha, String email, String nome){
		try{
			String query = "UPDATE cadastro SET senha = '" + senha + "', email = '" + email + "', nome = '" + nome + "' WHERE usuario = '" + usuario + "'; ";
			stmt = conn.createStatement();
			this.stmt.executeUpdate(query);
			JOptionPane.showMessageDialog(null, "Editado com sucesso! Voltando ao menu principal...");
			stmt.close();
		}catch (Exception e){
			System.out.println("Erro: " + e.getMessage());
		}
	}
	
	public void editarAssociado (String usuario, String senha, String email, String nome, int reservas, String telefone, String endereco, String bairro, String cidade, String estado ){
		try{
			String query = "UPDATE cadastro SET senha = '" + senha + "', email = '" + email + "', nome = '" + nome + "', reservas = '" + reservas + "', telefone = '" + telefone + "', endereco = '" + endereco + "', bairro = '" + bairro + "', cidade = '" + cidade + "', estado = '" + estado + "' WHERE usuario = '" + usuario + "'; ";
			stmt = conn.createStatement();
			this.stmt.executeUpdate(query);
			JOptionPane.showMessageDialog(null, "Editado com sucesso! Voltando ao menu principal...");
			stmt.close();
		}catch (Exception e){
			System.out.println("Erro: " + e.getMessage());
		}
	}
	
	public void editarLivro (String titulo, int paginas, String genero, String autor, String editora){
		try{
			String query = "UPDATE livro SET titulo = '"+ titulo + "', paginas = '" + paginas + "', genero = '"+ genero +"', autor = '" + autor + "', editora = '" + editora +"' WHERE titulo = '" + titulo + "'; ";
			stmt = conn.createStatement();
			this.stmt.executeUpdate(query);
			JOptionPane.showMessageDialog(null, "Livro editado com sucesso! Voltando ao menu principal...");
			stmt.close();
		}catch (Exception e){
			System.out.println("Erro: " + e.getMessage());
		}
	}
	
	public void excluiAdministrador(String id){
		try{
			String query = "DELETE FROM cadastro WHERE idCadastro = " + id + "; ";
			stmt = conn.createStatement();
			this.stmt.executeUpdate(query);
			JOptionPane.showMessageDialog(null, "Cadastro exclu�do com sucesso! Voltando ao menu principal...");
			stmt.close();
		}catch (Exception e){
			System.out.println("Erro: " + e.getMessage());
		}
	}
	
	public void excluiBibliotecario(String id){
		try{
			String query = "DELETE FROM cadastro WHERE idCadastro = " + id + "; ";
			stmt = conn.createStatement();
			this.stmt.executeUpdate(query);
			JOptionPane.showMessageDialog(null, "Cadastro exclu�do com sucesso! Voltando ao menu principal...");
			stmt.close();
		}catch (Exception e){
			System.out.println("Erro: " + e.getMessage());
		}
	}
	
	public void excluiAssociado(String id){
		try{
			String query = "DELETE FROM cadastro WHERE idCadastro = " + id + "; ";
			stmt = conn.createStatement();
			this.stmt.executeUpdate(query);
			JOptionPane.showMessageDialog(null, "Cadastro exclu�do com sucesso! Voltando ao menu principal...");
			stmt.close();
		}catch (Exception e){
			System.out.println("Erro: " + e.getMessage());
		}
	}
		
	public void excluiLivro(String id){
		try{
			String query = "DELETE FROM livro WHERE idLivro = " + id + "; ";
			stmt = conn.createStatement();
			this.stmt.executeUpdate(query);
			JOptionPane.showMessageDialog(null, "Livro exclu�do com sucesso! Voltando ao menu principal...");
			stmt.close();
		}catch (Exception e){
			System.out.println("Erro: " + e.getMessage());
		}
	}
	
	public void reservarLivro (int idReserva, int reservas, int numReservas, String idLivro){
		try{
			String query = "UPDATE livro SET idReserva = '" + idReserva + "', reservas = '" + reservas + "', dataReserva = '" + java.time.LocalDate.now() + "'WHERE idLivro = '" + idLivro + "';";
			String query2 = "UPDATE cadastro SET reservas = '" + numReservas + "' WHERE idCadastro = '" + idReserva + "'; ";
			String query3 = "UPDATE livro SET dataDevolver  = DATE_ADD(dataReserva,INTERVAL 30 DAY);";
			stmt = conn.createStatement();
			this.stmt.executeUpdate(query);
			this.stmt.executeUpdate(query2);
			this.stmt.executeUpdate(query3);
			JOptionPane.showMessageDialog(null, "Livro reservado com sucesso! O prazo para devolu��o � um m�s!");
		}catch (Exception e){
			System.out.println("Erro: " + e.getMessage());
		}
	}
	
	public void devolverLivro (String idLivro){
		try{
			String query = "UPDATE livro SET idReserva = null, dataReserva = null, dataDevolver = null WHERE idLivro = '" + idLivro + "';";
			stmt = conn.createStatement();
			this.stmt.executeUpdate(query);
			JOptionPane.showMessageDialog(null, "Livro devolvido com sucesso!");
		}catch (Exception e){
			System.out.println("Erro: " + e.getMessage());
		}
	}
	
	public String multa () throws SQLException{
		
		int retorn = 0;
		String query = "SELECT dataReserva,DATEDIFF(dataDevolver,curdate()) FROM livro;";
		stmt = conn.createStatement();
		rs = stmt.executeQuery(query);
		if(!rs.next()){
			 JOptionPane.showMessageDialog(null, "N�o localizado no cadastro!");}
		else{
			rs.previous();
			while(rs.next()){
				retorn = rs.getInt("DATEDIFF(dataDevolver,curdate())");
			}
		}
		retorn *= -1;
		return Integer.toString(retorn);

	}
	
	public void desconectar(){
		try{
			this.conn.close();
		}catch(Exception e){
			System.out.println("Erro: " + e.getMessage());
		}
	}
	
}