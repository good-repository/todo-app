package projetoStart;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;

public class DevolverLivro extends Autenticacao {

	private JPanel contentPane;
	private JTextField txtPagina;
	private JTextField txtTitulo;
	private JTextField txtGenero;
	private JTextField txtAutor;
	private JTextField txtPesquisa;
	private JTextField txtEditora;
	
	BancoDeDados banco = new BancoDeDados();
	String[] pesquisa = new String[15];
	private JTextField txtReserva;
	private JTextField txtDevolv;
	

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					DevolverLivro frame = new DevolverLivro();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	
	public DevolverLivro() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 794, 446);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblTitulo = new JLabel("T�tulo:");
		lblTitulo.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblTitulo.setBounds(149, 120, 65, 30);
		contentPane.add(lblTitulo);
		
		JLabel lblGenero = new JLabel("G�nero:");
		lblGenero.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblGenero.setBounds(149, 163, 65, 30);
		contentPane.add(lblGenero);
		
		JLabel lblAutor = new JLabel("Autor:");
		lblAutor.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblAutor.setBounds(149, 206, 52, 30);
		contentPane.add(lblAutor);
		
		JLabel lblPagina = new JLabel("P�gina:");
		lblPagina.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblPagina.setBounds(149, 249, 65, 30);
		contentPane.add(lblPagina);
		
		txtPagina = new JTextField();
		txtPagina.setFont(new Font("Tahoma", Font.PLAIN, 15));
		txtPagina.setBounds(260, 254, 260, 22);
		contentPane.add(txtPagina);
		txtPagina.setColumns(10);
		
		txtTitulo = new JTextField();
		txtTitulo.setFont(new Font("Tahoma", Font.PLAIN, 15));
		txtTitulo.setBounds(260, 125, 260, 22);
		contentPane.add(txtTitulo);
		txtTitulo.setColumns(10);
		
		txtGenero = new JTextField();
		txtGenero.setFont(new Font("Tahoma", Font.PLAIN, 15));
		txtGenero.setBounds(260, 168, 260, 22);
		contentPane.add(txtGenero);
		txtGenero.setColumns(10);
		
		txtAutor = new JTextField();
		txtAutor.setFont(new Font("Tahoma", Font.PLAIN, 15));
		txtAutor.setBounds(260, 211, 260, 22);
		contentPane.add(txtAutor);
		txtAutor.setColumns(10);
		
		JButton btnPesquisar = new JButton("Pesquisar");
		btnPesquisar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				banco.conectar();
				if (txtPesquisa.getText().trim().equals("")){
					JOptionPane.showMessageDialog(null, "Insira algum valor para a pesquisa!");
				}else if(banco.estaConectado()){
				pesquisa = banco.buscarLivro(txtPesquisa.getText());
				
					txtTitulo.setText(pesquisa[1]);
					txtGenero.setText(pesquisa[3]);
					txtPagina.setText(pesquisa[2]);
					txtAutor.setText(pesquisa[4]);
					txtEditora.setText(pesquisa[6]);
					txtDevolv.setText(pesquisa[9]);
					if (Integer.parseInt(pesquisa[7]) == 0 || pesquisa[7] == null){
						txtReserva.setText("Dispon�vel para reserva!");
					}else{
						txtReserva.setText(pesquisa[7]);
					};
					banco.desconectar();
					
				}
			}
		});
		btnPesquisar.setBounds(154, 56, 130, 50);
		contentPane.add(btnPesquisar);
		
		JButton btnSair = new JButton("Sair");
		btnSair.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				DevolverLivro.this.dispose();
				}	
		});
		btnSair.setBounds(559, 56, 130, 50);
		contentPane.add(btnSair);
		
		JLabel lblTopo = new JLabel("Digite o t�tulo ou n�mero de registro do livro:");
		lblTopo.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblTopo.setBounds(12, 13, 500, 30);
		contentPane.add(lblTopo);
		
		txtPesquisa = new JTextField();
		txtPesquisa.setFont(new Font("Tahoma", Font.PLAIN, 15));
		txtPesquisa.setBounds(435, 19, 254, 22);
		contentPane.add(txtPesquisa);
		txtPesquisa.setColumns(10);
		
		JLabel lblEditora = new JLabel("Editora:");
		lblEditora.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblEditora.setBounds(149, 292, 61, 30);
		contentPane.add(lblEditora);
		
		txtEditora = new JTextField();
		txtEditora.setFont(new Font("Tahoma", Font.PLAIN, 15));
		txtEditora.setBounds(260, 297, 260, 22);
		contentPane.add(txtEditora);
		txtEditora.setColumns(10);
		
		JButton btnDevolver = new JButton("Devolver");
		btnDevolver.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			banco.conectar();	
			if(banco.estaConectado()){
				if((pesquisa[7] != null) || (Integer.parseInt(pesquisa[7]) != 0)){
					banco.devolverLivro(txtPesquisa.getText());
					}
				}else{
					JOptionPane.showMessageDialog(null, "O livro n�o estava reservado, verifique o ID.");
				}
			DevolverLivro.this.dispose();
			banco.desconectar();	
			}
		});
		btnDevolver.setBounds(353, 56, 130, 50);
		contentPane.add(btnDevolver);
		
		JLabel lblReservante = new JLabel("Reservante:");
		lblReservante.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblReservante.setBounds(149, 342, 92, 16);
		contentPane.add(lblReservante);
		
		txtReserva = new JTextField();
		txtReserva.setFont(new Font("Tahoma", Font.PLAIN, 15));
		txtReserva.setBounds(260, 340, 260, 22);
		contentPane.add(txtReserva);
		txtReserva.setColumns(10);
		
		JLabel lblDataPrevistaPara = new JLabel("Data prevista para devolver:");
		lblDataPrevistaPara.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblDataPrevistaPara.setBounds(149, 382, 221, 16);
		contentPane.add(lblDataPrevistaPara);
		
		txtDevolv = new JTextField();
		txtDevolv.setFont(new Font("Tahoma", Font.PLAIN, 15));
		txtDevolv.setBounds(382, 381, 138, 22);
		contentPane.add(txtDevolv);
		txtDevolv.setColumns(10);
	}
}
