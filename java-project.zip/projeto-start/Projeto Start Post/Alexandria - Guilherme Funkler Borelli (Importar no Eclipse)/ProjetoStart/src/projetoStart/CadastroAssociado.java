package projetoStart;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class CadastroAssociado extends JFrame {

	private JPanel contentPane;
	private JTextField txtUsuario;
	private JTextField txtSenha;
	private JTextField txtNome;
	private JTextField txtEmail;
	private JTextField txtTelefone;
	private JTextField txtEndereco;
	private JTextField txtEstado;
	private JTextField txtBairro;
	private JTextField txtCidade;
	
	BancoDeDados banco = new BancoDeDados();


	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CadastroAssociado frame = new CadastroAssociado();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public CadastroAssociado() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 794, 415);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblUsuario = new JLabel("Usu�rio:");
		lblUsuario.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblUsuario.setBounds(12, 60, 65, 30);
		contentPane.add(lblUsuario);
		
		JLabel lblSenha = new JLabel("Senha:");
		lblSenha.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblSenha.setBounds(22, 103, 54, 30);
		contentPane.add(lblSenha);
		
		JLabel lblNome = new JLabel("Nome:");
		lblNome.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNome.setBounds(25, 146, 52, 30);
		contentPane.add(lblNome);
		
		JLabel lblEmail = new JLabel("Email:");
		lblEmail.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblEmail.setBounds(29, 189, 48, 30);
		contentPane.add(lblEmail);
		
		txtUsuario = new JTextField();
		txtUsuario.setFont(new Font("Tahoma", Font.PLAIN, 15));
		txtUsuario.setBounds(89, 65, 169, 22);
		contentPane.add(txtUsuario);
		txtUsuario.setColumns(10);
		
		txtSenha = new JTextField();
		txtSenha.setFont(new Font("Tahoma", Font.PLAIN, 15));
		txtSenha.setBounds(89, 108, 260, 22);
		contentPane.add(txtSenha);
		txtSenha.setColumns(10);
		
		txtNome = new JTextField();
		txtNome.setFont(new Font("Tahoma", Font.PLAIN, 15));
		txtNome.setBounds(89, 151, 260, 22);
		contentPane.add(txtNome);
		txtNome.setColumns(10);
		
		txtEmail = new JTextField();
		txtEmail.setFont(new Font("Tahoma", Font.PLAIN, 15));
		txtEmail.setBounds(89, 194, 260, 22);
		contentPane.add(txtEmail);
		txtEmail.setColumns(10);
		
		JButton btnCadastrar = new JButton("Cadastrar");
		btnCadastrar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				banco.conectar();
				if(banco.estaConectado()){
					if(txtBairro.getText().trim().equals("")){
						JOptionPane.showMessageDialog(null, "Campo Cidade sem dados!");
					}else if (txtEmail.getText().trim().equals("")){
						JOptionPane.showMessageDialog(null, "Campo Email sem dados!");
					}else if (txtEndereco.getText().trim().equals("")){
						JOptionPane.showMessageDialog(null, "Campo Endere�o sem dados!");
					}else if (txtEstado.getText().trim().equals("")){
						JOptionPane.showMessageDialog(null, "Campo Estado sem dados!");
					}else if (txtNome.getText().trim().equals("")){
						JOptionPane.showMessageDialog(null, "Campo Nome sem dados!");
					}else if (txtSenha.getText().trim().equals("")){
						JOptionPane.showMessageDialog(null, "Campo Senha sem dados!");
					}else if (txtTelefone.getText().trim().equals("")){
						JOptionPane.showMessageDialog(null, "Campo Telefone sem dados!");
					}else if (txtUsuario.getText().trim().equals("")){
						JOptionPane.showMessageDialog(null, "Campo Usuario sem dados!");
					}else if (txtBairro.getText().trim().equals("")){
						JOptionPane.showMessageDialog(null, "Campo Bairro sem dados!");
					}else{
						banco.inserirAssociado(txtUsuario.getText(), txtSenha.getText(), txtEmail.getText(), txtNome.getText(), 0,txtTelefone.getText(), txtEndereco.getText(), txtBairro.getText(), txtCidade.getText(), txtEstado.getText());
						CadastroAssociado.this.dispose();
					}
				}else {
					JOptionPane.showMessageDialog(null, "Erro!");
				}
				banco.desconectar();
			}
		});
		btnCadastrar.setBounds(219, 307, 130, 50);
		contentPane.add(btnCadastrar);
		
		JButton btnCancelar = new JButton("Cancelar");
		btnCancelar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				CadastroAssociado.this.dispose();
			}
		});
		btnCancelar.setBounds(443, 307, 130, 50);
		contentPane.add(btnCancelar);
		
		JLabel lblDigiteTodosOs = new JLabel("Digite todos os dados abaixo para efetuar o cadastro de um novo associado");
		lblDigiteTodosOs.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblDigiteTodosOs.setBounds(52, 13, 712, 30);
	
		contentPane.add(lblDigiteTodosOs);
		
		JLabel lblTelefone = new JLabel("Telefone:");
		lblTelefone.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblTelefone.setBounds(3, 232, 74, 22);
		contentPane.add(lblTelefone);
		
		txtTelefone = new JTextField();
		txtTelefone.setFont(new Font("Tahoma", Font.PLAIN, 15));
		txtTelefone.setBounds(89, 234, 260, 22);
		contentPane.add(txtTelefone);
		txtTelefone.setColumns(10);
		
		JLabel lblEndereco = new JLabel("Endere�o:");
		lblEndereco.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblEndereco.setBounds(270, 67, 78, 16);
		contentPane.add(lblEndereco);
		
		txtEndereco = new JTextField();
		txtEndereco.setFont(new Font("Tahoma", Font.PLAIN, 15));
		txtEndereco.setBounds(360, 65, 404, 22);
		contentPane.add(txtEndereco);
		txtEndereco.setColumns(10);
		
		JLabel lblEstado = new JLabel("Estado:");
		lblEstado.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblEstado.setBounds(372, 196, 59, 16);
		contentPane.add(lblEstado);
		
		txtEstado = new JTextField();
		txtEstado.setFont(new Font("Tahoma", Font.PLAIN, 15));
		txtEstado.setBounds(443, 194, 257, 22);
		contentPane.add(txtEstado);
		txtEstado.setColumns(10);
		
		JLabel lblCidade = new JLabel("Cidade:");
		lblCidade.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblCidade.setBounds(372, 153, 59, 16);
		contentPane.add(lblCidade);
		
		txtBairro = new JTextField();
		txtBairro.setFont(new Font("Tahoma", Font.PLAIN, 15));
		txtBairro.setBounds(440, 109, 260, 22);
		contentPane.add(txtBairro);
		txtBairro.setColumns(10);
		
		JLabel lblBairro = new JLabel("Bairro:");
		lblBairro.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblBairro.setBounds(375, 110, 56, 16);
		contentPane.add(lblBairro);
		
		txtCidade = new JTextField();
		txtCidade.setFont(new Font("Tahoma", Font.PLAIN, 15));
		txtCidade.setBounds(440, 152, 260, 22);
		contentPane.add(txtCidade);
		txtCidade.setColumns(10);
	}

}
