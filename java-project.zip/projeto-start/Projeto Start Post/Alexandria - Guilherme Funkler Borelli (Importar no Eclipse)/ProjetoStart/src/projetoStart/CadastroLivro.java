package projetoStart;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;

public class CadastroLivro extends JFrame {

	
	
	private JPanel contentPane;
	private JTextField txtTitulo;
	private JTextField txtPaginas;
	private JTextField txtGenero;
	private JTextField txtAutor;
	private JTextField txtEditora;
	
	BancoDeDados banco = new BancoDeDados();
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CadastroLivro frame = new CadastroLivro();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public CadastroLivro() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 670, 406);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblTitulo = new JLabel("T�tulo:");
		lblTitulo.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblTitulo.setBounds(74, 60, 65, 30);
		contentPane.add(lblTitulo);
		
		JLabel lblPagina = new JLabel("P�ginas: ");
		lblPagina.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblPagina.setBounds(74, 103, 72, 30);
		contentPane.add(lblPagina);
		
		JLabel lblGenero = new JLabel("G�nero: ");
		lblGenero.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblGenero.setBounds(74, 146, 68, 30);
		contentPane.add(lblGenero);
		
		JLabel lblAutor = new JLabel("Autor: ");
		lblAutor.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblAutor.setBounds(74, 189, 55, 30);
		contentPane.add(lblAutor);
		
		txtTitulo = new JTextField();
		txtTitulo.setFont(new Font("Tahoma", Font.PLAIN, 15));
		txtTitulo.setBounds(151, 65, 309, 22);
		contentPane.add(txtTitulo);
		txtTitulo.setColumns(10);
		
		txtPaginas = new JTextField();
		txtPaginas.setFont(new Font("Tahoma", Font.PLAIN, 15));
		txtPaginas.setBounds(151, 108, 309, 22);
		contentPane.add(txtPaginas);
		txtPaginas.setColumns(10);
		
		txtGenero = new JTextField();
		txtGenero.setFont(new Font("Tahoma", Font.PLAIN, 15));
		txtGenero.setBounds(151, 151, 309, 22);
		contentPane.add(txtGenero);
		txtGenero.setColumns(10);
		
		txtAutor = new JTextField();
		txtAutor.setFont(new Font("Tahoma", Font.PLAIN, 15));
		txtAutor.setBounds(151, 194, 309, 22);
		contentPane.add(txtAutor);
		txtAutor.setColumns(10);
		
		JButton btnCadastrar = new JButton("Cadastrar");
		btnCadastrar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				banco.conectar();
				if(banco.estaConectado()){
					if(txtAutor.getText().trim().equals("")){
						JOptionPane.showMessageDialog(null, "Campo Autor sem dados!");
					}else if(txtGenero.getText().trim().equals("")){
						JOptionPane.showMessageDialog(null, "Campo G�nero sem dados!");
					}else if(txtPaginas.getText().trim().equals("")){
						JOptionPane.showMessageDialog(null, "Campo P�ginas sem dados!");
					}else if (txtTitulo.getText().trim().equals("")){
						JOptionPane.showMessageDialog(null, "Campo T�tulo sem dados!");
					}else if (txtEditora.getText().trim().equals("")){
						JOptionPane.showMessageDialog(null, "Campo Editora sem dados!");
					}else{
						banco.inserirLivro(txtTitulo.getText(), Integer.parseInt(txtPaginas.getText()), txtGenero.getText(), txtAutor.getText(), txtEditora.getText());
						CadastroLivro.this.dispose();
					}
				}else{
					JOptionPane.showMessageDialog(null, "Erro!");
				}
				banco.desconectar();
			}
		});
		btnCadastrar.setBounds(84, 286, 130, 50);
		contentPane.add(btnCadastrar);
		
		JButton btnCancelar = new JButton("Cancelar");
		btnCancelar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				CadastroLivro.this.dispose();
			}
		});
		btnCancelar.setBounds(330, 286, 130, 50);
		contentPane.add(btnCancelar);
		
		JLabel lblTopo = new JLabel("Digite todos os dados abaixo para efetuar o cadastro de um novo livro");
		lblTopo.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblTopo.setBounds(12, 13, 628, 30);
		contentPane.add(lblTopo);
		
		JLabel lblEditora = new JLabel("Editora: ");
		lblEditora.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblEditora.setBounds(74, 232, 72, 30);
		contentPane.add(lblEditora);
		
		txtEditora = new JTextField();
		txtEditora.setFont(new Font("Tahoma", Font.PLAIN, 15));
		txtEditora.setBounds(151, 238, 309, 22);
		contentPane.add(txtEditora);
		txtEditora.setColumns(10);
	}
}
