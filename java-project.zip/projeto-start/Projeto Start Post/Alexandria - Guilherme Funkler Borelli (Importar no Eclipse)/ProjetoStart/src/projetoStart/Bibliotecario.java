package projetoStart;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

public class Bibliotecario extends Administrador {

	
	private JPanel contentPane;
	
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Bibliotecario frame = new Bibliotecario();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	public void cadastraLivro(){
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CadastroLivro frame = new CadastroLivro();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	};
	public void editarLivro(){
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					EditaLivro frame = new EditaLivro();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	};
	public void excluirLivro(){
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ExcluiLivro frame = new ExcluiLivro();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	};
	public void consultarLivro(){
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ConsultaLivro frame = new ConsultaLivro();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	};
	public void emprestimo(){
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ReservarLivro frame = new ReservarLivro();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	};
	public void devolucao(){
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					DevolverLivro frame = new DevolverLivro();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	};
	public void gerarMulta(){
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Multa frame = new Multa();
					frame.setVisible(true);
				}catch (Exception e){
					e.printStackTrace();
				}
			}
		});
	};
	
	
	/**
	 * Create the frame.
	 */

	public Bibliotecario() {
		setTitle("Alexandria Gest�o de Bibliotecas V0.7 beta");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 992, 450);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Ol� bibliotec�rio, selecione a a��o desejada!");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel.setBounds(313, 0, 359, 64);
		contentPane.add(lblNewLabel);
		
		JButton btnCadastrarLivro = new JButton("Cadastrar Livro");
		btnCadastrarLivro.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cadastraLivro();
			}
		});
		btnCadastrarLivro.setBounds(362, 80, 250, 50);
		contentPane.add(btnCadastrarLivro);
		
		JButton btnCadastraAssociado = new JButton("Cadastrar Associado(a)");
		btnCadastraAssociado.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			cadastraAssociado();
			}
		});
		btnCadastraAssociado.setBounds(12, 80, 250, 50);
		contentPane.add(btnCadastraAssociado);
		
		JButton btnEditarLivro = new JButton("Editar Livro");
		btnEditarLivro.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				editarLivro();
			}
		});
		btnEditarLivro.setBounds(362, 165, 250, 50);
		contentPane.add(btnEditarLivro);
		
		JButton btnEditaAssociado = new JButton("Editar Associado(a)");
		btnEditaAssociado.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				editaAssociado();
			}
		});
		btnEditaAssociado.setBounds(12, 165, 250, 50);
		contentPane.add(btnEditaAssociado);
		
		JButton btnExcluirLivro = new JButton("Excluir Livro");
		btnExcluirLivro.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				excluirLivro();
			}
		});
		btnExcluirLivro.setBounds(362, 250, 250, 50);
		contentPane.add(btnExcluirLivro);
		
		JButton btnExcluiAssociado = new JButton("Excluir Associado(a)");
		btnExcluiAssociado.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			excluiAssociado();
			}
		});
		btnExcluiAssociado.setBounds(12, 250, 250, 50);
		contentPane.add(btnExcluiAssociado);
		
		JButton btnConsultarLivro = new JButton("Consultar no Acervo");
		btnConsultarLivro.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			consultarLivro();	
			}
		});
		btnConsultarLivro.setBounds(712, 165, 250, 50);
		contentPane.add(btnConsultarLivro);
		
		JButton btnGerarMulta = new JButton("Gerar Multa");
		btnGerarMulta.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				gerarMulta();
			}
		});
		btnGerarMulta.setBounds(362, 335, 250, 50);
		contentPane.add(btnGerarMulta);
		
		JButton btnEscreverEmail = new JButton("Escrever E-mail");
		btnEscreverEmail.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				email();
			}
		});
		btnEscreverEmail.setBounds(12, 335, 250, 50);
		contentPane.add(btnEscreverEmail);
		
		JButton btnConsultarCadastro = new JButton("Consultar no Cadastro");
		btnConsultarCadastro.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			consultaCadastro();
			}
		});
		btnConsultarCadastro.setBounds(712, 80, 250, 50);
		contentPane.add(btnConsultarCadastro);
		
		JButton btnEmprestimo = new JButton("Empr�stimo de Livro");
		btnEmprestimo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				emprestimo();
			}
		});
		btnEmprestimo.setBounds(712, 250, 250, 50);
		contentPane.add(btnEmprestimo);
		
		JButton btnDevolucao = new JButton("Devolu��o de Livro");
		btnDevolucao.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				devolucao();
			}
		});
		btnDevolucao.setBounds(712, 335, 250, 50);
		contentPane.add(btnDevolucao);
	}
}
