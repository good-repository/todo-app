package projetoStart;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

public class EditaAssociado extends JFrame {

	private JPanel contentPane;
	private JTextField txtUsuario;
	private JTextField txtSenha;
	private JTextField txtNome;
	private JTextField txtEmail;
	private JTextField txtTelefone;
	private JTextField txtEndereco;
	private JTextField txtEstado;
	private JTextField txtBairro;
	private JTextField txtCidade;
	private JTextField txtPesquisa;
	private JTextField txtRegistro;
	private JTextField txtReservas;

	
	BancoDeDados banco = new BancoDeDados();
	String[] retorno = new String[15];
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					EditaAssociado frame = new EditaAssociado();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	
	public EditaAssociado() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 794, 415);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblUsuario = new JLabel("Usu�rio:");
		lblUsuario.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblUsuario.setBounds(12, 140, 65, 30);
		contentPane.add(lblUsuario);
		
		JLabel lblSenha = new JLabel("Senha:");
		lblSenha.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblSenha.setBounds(23, 179, 54, 30);
		contentPane.add(lblSenha);
		
		JLabel lblNome = new JLabel("Nome:");
		lblNome.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNome.setBounds(25, 215, 52, 30);
		contentPane.add(lblNome);
		
		JLabel lblEmail = new JLabel("Email:");
		lblEmail.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblEmail.setBounds(29, 258, 48, 30);
		contentPane.add(lblEmail);
		
		txtUsuario = new JTextField();
		txtUsuario.setFont(new Font("Tahoma", Font.PLAIN, 15));
		txtUsuario.setBounds(89, 145, 169, 22);
		contentPane.add(txtUsuario);
		txtUsuario.setColumns(10);
		
		txtSenha = new JTextField();
		txtSenha.setFont(new Font("Tahoma", Font.PLAIN, 15));
		txtSenha.setBounds(89, 180, 260, 22);
		contentPane.add(txtSenha);
		txtSenha.setColumns(10);
		
		txtNome = new JTextField();
		txtNome.setFont(new Font("Tahoma", Font.PLAIN, 15));
		txtNome.setBounds(89, 220, 260, 22);
		contentPane.add(txtNome);
		txtNome.setColumns(10);
		
		txtEmail = new JTextField();
		txtEmail.setFont(new Font("Tahoma", Font.PLAIN, 15));
		txtEmail.setBounds(89, 260, 260, 22);
		contentPane.add(txtEmail);
		txtEmail.setColumns(10);
		
		JButton btnPesquisar = new JButton("Pesquisar");
		btnPesquisar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				banco.conectar();
				if (txtPesquisa.getText().trim().equals("")){
					JOptionPane.showMessageDialog(null, "Insira algum valor para a pesquisa!");
				}else if(banco.estaConectado()){
				retorno = banco.buscarContato(txtPesquisa.getText());
				if(Integer.parseInt(retorno[11]) == 3){
				txtRegistro.setText(retorno[0]);
				txtUsuario.setText(retorno[1]);
				txtSenha.setText(retorno[2]);
				txtEmail.setText(retorno[3]);
				txtNome.setText(retorno[4]);
				txtReservas.setText(retorno[5]);
				txtTelefone.setText(retorno[6]);
				txtEndereco.setText(retorno[7]);
				txtBairro.setText(retorno[8]);
				txtCidade.setText(retorno[9]);
				txtEstado.setText(retorno[10]);
				}else{
					JOptionPane.showMessageDialog(null, "Este usu�rio n�o � um assoiado!");
				}
				banco.desconectar();
				}
			}
		});
		btnPesquisar.setBounds(128, 64, 130, 50);
		contentPane.add(btnPesquisar);
		
		JButton btnAlterar = new JButton("Salvar Altera��es");
		btnAlterar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				banco.conectar();
				if(banco.estaConectado()){
					if(txtEmail.getText().trim().equals("")){
						JOptionPane.showMessageDialog(null, "Campo Email sem dados!");
					}else if(txtNome.getText().trim().equals("")){
						JOptionPane.showMessageDialog(null, "Campo Nome sem dados!");
					}else if(txtSenha.getText().trim().equals("")){
						JOptionPane.showMessageDialog(null, "Campo Senha sem dados!");
					}else if (txtUsuario.getText().trim().equals("")){
						JOptionPane.showMessageDialog(null, "Campo Usu�rio sem dados!");
					}else if (txtBairro.getText().trim().equals("")){
						JOptionPane.showMessageDialog(null, "Campo Bairro sem dados!");
					}else if (txtCidade.getText().trim().equals("")){
						JOptionPane.showMessageDialog(null, "Campo Cidade sem dados!");
					}else if (txtEndereco.getText().trim().equals("")){
						JOptionPane.showMessageDialog(null, "Campo Endere�o sem dados!");
					}else if (txtEstado.getText().trim().equals("")){
						JOptionPane.showMessageDialog(null, "Campo Estado sem dados!");
					}else if (txtReservas.getText().trim().equals("")){
						JOptionPane.showMessageDialog(null, "Campo Reservas sem dados!");
					}else if (txtTelefone.getText().trim().equals("")){
						JOptionPane.showMessageDialog(null, "Campo Telefone sem dados!");	
					}else{
						banco.editarAssociado(txtUsuario.getText(), txtSenha.getText(), txtEmail.getText(), txtNome.getText(), Integer.parseInt(txtReservas.getText()), txtTelefone.getText(), txtEndereco.getText(), txtBairro.getText(), txtCidade.getText(), txtEstado.getText());
						EditaAssociado.this.dispose();
					}
					}else{
						JOptionPane.showMessageDialog(null, "Ocorreu um erro, favor tentar novamente!");
					}
					banco.desconectar();
				}	
			
		});
		btnAlterar.setBounds(480, 64, 139, 50);
		contentPane.add(btnAlterar);
		
		JLabel lblTelefone = new JLabel("Telefone:");
		lblTelefone.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblTelefone.setBounds(3, 299, 74, 22);
		contentPane.add(lblTelefone);
		
		txtTelefone = new JTextField();
		txtTelefone.setFont(new Font("Tahoma", Font.PLAIN, 15));
		txtTelefone.setBounds(89, 300, 260, 22);
		contentPane.add(txtTelefone);
		txtTelefone.setColumns(10);
		
		JLabel lblEndereco = new JLabel("Endere\u00E7o:");
		lblEndereco.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblEndereco.setBounds(270, 147, 78, 16);
		contentPane.add(lblEndereco);
		
		txtEndereco = new JTextField();
		txtEndereco.setFont(new Font("Tahoma", Font.PLAIN, 15));
		txtEndereco.setBounds(360, 141, 404, 22);
		contentPane.add(txtEndereco);
		txtEndereco.setColumns(10);
		
		JLabel lblEstado = new JLabel("Estado:");
		lblEstado.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblEstado.setBounds(372, 265, 59, 16);
		contentPane.add(lblEstado);
		
		txtEstado = new JTextField();
		txtEstado.setFont(new Font("Tahoma", Font.PLAIN, 15));
		txtEstado.setBounds(443, 263, 260, 22);
		contentPane.add(txtEstado);
		txtEstado.setColumns(10);
		
		JLabel lblCidade = new JLabel("Cidade:");
		lblCidade.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblCidade.setBounds(372, 222, 59, 16);
		contentPane.add(lblCidade);
		
		txtBairro = new JTextField();
		txtBairro.setFont(new Font("Tahoma", Font.PLAIN, 15));
		txtBairro.setBounds(443, 180, 260, 22);
		contentPane.add(txtBairro);
		txtBairro.setColumns(10);
		
		JLabel lblBairro = new JLabel("Bairro:");
		lblBairro.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblBairro.setBounds(375, 182, 56, 16);
		contentPane.add(lblBairro);
		
		txtCidade = new JTextField();
		txtCidade.setFont(new Font("Tahoma", Font.PLAIN, 15));
		txtCidade.setBounds(443, 221, 260, 22);
		contentPane.add(txtCidade);
		txtCidade.setColumns(10);
		
		JLabel lblDigiteO = new JLabel("Digite o nome ou n�mero de registro do associado:");
		lblDigiteO.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblDigiteO.setBounds(21, 13, 407, 21);
		contentPane.add(lblDigiteO);
		
		txtPesquisa = new JTextField();
		txtPesquisa.setFont(new Font("Tahoma", Font.PLAIN, 15));
		txtPesquisa.setBounds(440, 12, 324, 22);
		contentPane.add(txtPesquisa);
		txtPesquisa.setColumns(10);
		
		JLabel lblNmeroDeRegistro = new JLabel("N�mero de Registro:");
		lblNmeroDeRegistro.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNmeroDeRegistro.setBounds(370, 299, 163, 22);
		contentPane.add(lblNmeroDeRegistro);
		
		txtRegistro = new JTextField();
		txtRegistro.setFont(new Font("Tahoma", Font.PLAIN, 15));
		txtRegistro.setBounds(545, 301, 158, 22);
		contentPane.add(txtRegistro);
		txtRegistro.setColumns(10);
		
		JLabel lblReservas = new JLabel("Reservas:");
		lblReservas.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblReservas.setBounds(372, 339, 92, 16);
		contentPane.add(lblReservas);
		
		txtReservas = new JTextField();
		txtReservas.setFont(new Font("Tahoma", Font.PLAIN, 15));
		txtReservas.setBounds(454, 338, 116, 22);
		contentPane.add(txtReservas);
		txtReservas.setColumns(10);
	}
}
