package projetoStart;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import java.awt.Window.Type;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;

public class Autenticacao extends JFrame implements ActionListener {

	private JPanel contentPane;
	private JTextField textFieldUsuario;
	private JTextField textFieldSenha;
	
	BancoDeDados banco = new BancoDeDados();
	static String[] retorno = new String[15];
	Associado associado = new Associado();
	Bibliotecario bibliotecario = new Bibliotecario();
	Administrador admin = new Administrador();
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Autenticacao frame = new Autenticacao();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
		
		
	}

	public Autenticacao() {
		setResizable(false);
		setTitle("Alexandria Gest�o de Bibliotecas V0.7 beta");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 700, 548);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(null);
		setContentPane(contentPane);
		
		JLabel lblUsurio = new JLabel("Usu�rio:");
		lblUsurio.setFont(new Font("Tahoma", Font.PLAIN, 25));
		lblUsurio.setBounds(108, 164, 92, 31);
		contentPane.add(lblUsurio);
		
		JLabel lblSenha = new JLabel("Senha:");
		lblSenha.setFont(new Font("Tahoma", Font.PLAIN, 25));
		lblSenha.setBounds(108, 240, 77, 31);
		contentPane.add(lblSenha);
		
		textFieldUsuario = new JTextField();
		textFieldUsuario.setFont(new Font("Tahoma", Font.PLAIN, 18));
		textFieldUsuario.setBounds(212, 169, 230, 31);
		contentPane.add(textFieldUsuario);
		textFieldUsuario.setColumns(10);
		
		textFieldSenha = new JTextField();
		textFieldSenha.setFont(new Font("Tahoma", Font.PLAIN, 18));
		textFieldSenha.setBounds(212, 245, 230, 31);
		contentPane.add(textFieldSenha);
		textFieldSenha.setColumns(10);
		
		JLabel lblBemVindoFavor = new JLabel("Bem vindo! Favor identifique-se utilizando seu usu�rio e senha.");
		lblBemVindoFavor.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblBemVindoFavor.setBounds(108, 46, 490, 40);
		contentPane.add(lblBemVindoFavor);
		
		JButton btnValidar = new JButton("Validar");
		btnValidar.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnValidar.setBounds(108, 357, 130, 50);
		contentPane.add(btnValidar);
		btnValidar.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
				banco.conectar();
				if (textFieldUsuario.getText().trim().equals("") && textFieldSenha.getText().trim().equals("")){
					JOptionPane.showMessageDialog(null, "Insira usuario e senha!");
				}else if(banco.estaConectado()){
					retorno = (banco.login(textFieldUsuario.getText()));
					if(retorno[1].contains(textFieldUsuario.getText()) || retorno[0].contains(textFieldUsuario.getText())){
						if(retorno[2].equals(textFieldSenha.getText())){
							if(retorno[11].contains("1")){
							admin.setVisible(true);
							textFieldSenha.setText("");
							textFieldUsuario.setText("");
							}else if(retorno[11].contains("2")){
							bibliotecario.setVisible(true);
							textFieldSenha.setText("");
							textFieldUsuario.setText("");
							}else if(retorno[11].contains("3")){
							associado.setVisible(true);
							textFieldSenha.setText("");
							textFieldUsuario.setText("");
								}
							}else{
								JOptionPane.showMessageDialog(null, "Senha incorreta!");}
						}
				}else {
					JOptionPane.showMessageDialog(null, "Usu�rio inexistente!");
				}
				banco.desconectar();
			}
		});
		
		JButton btnSair = new JButton("Sair");
		btnSair.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnSair.setBounds(392, 357, 130, 50);
		contentPane.add(btnSair);
		btnSair.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null, "Encerrando o Programa!");	
				System.exit(0);
			}
		});
		
		JButton btnLimpar = new JButton("Limpar");
		btnLimpar.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnLimpar.setBounds(250, 357, 130, 50);
		contentPane.add(btnLimpar);
		btnLimpar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textFieldSenha.setText("");
				textFieldUsuario.setText("");
			}
		});
	}
	public void actionPerformed(ActionEvent e) {
	}	
}
