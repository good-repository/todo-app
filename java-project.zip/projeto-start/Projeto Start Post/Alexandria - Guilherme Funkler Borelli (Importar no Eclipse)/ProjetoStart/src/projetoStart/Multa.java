package projetoStart;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;

public class Multa extends Autenticacao {

	private JPanel contentPane;
	private JTextField txtPesquisa;
	
	BancoDeDados banco = new BancoDeDados();
	String[] pesquisa = new String[15];
	private JTextField txtAtraso;
	private JTextField txtReserva;
	private JTextField txtDevolucao;
	private JTextField txtValor;
	private JTextField txtMulta;
	

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Multa frame = new Multa();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	
	public Multa() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 794, 296);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnPesquisar = new JButton("Pesquisar");
		btnPesquisar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				banco.conectar();
				if (txtPesquisa.getText().trim().equals("")){
					JOptionPane.showMessageDialog(null, "Insira algum valor para a pesquisa!");
				}else if(banco.estaConectado()){
				pesquisa = banco.buscarLivro(txtPesquisa.getText());
				txtDevolucao.setText(pesquisa[9]);
				txtReserva.setText(pesquisa[8]);
				try {
					txtAtraso.setText(banco.multa());
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
					
					banco.desconectar();
					
				}
			}
		});
		btnPesquisar.setBounds(154, 56, 130, 50);
		contentPane.add(btnPesquisar);
		
		JButton btnSair = new JButton("Sair");
		btnSair.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Multa.this.dispose();
				}	
		});
		btnSair.setBounds(559, 56, 130, 50);
		contentPane.add(btnSair);
		
		JLabel lblTopo = new JLabel("Digite o t�tulo ou n�mero de registro do livro:");
		lblTopo.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblTopo.setBounds(12, 13, 500, 30);
		contentPane.add(lblTopo);
		
		txtPesquisa = new JTextField();
		txtPesquisa.setFont(new Font("Tahoma", Font.PLAIN, 15));
		txtPesquisa.setBounds(435, 19, 254, 22);
		contentPane.add(txtPesquisa);
		txtPesquisa.setColumns(10);
		
		JButton btnMulta = new JButton("Gerar multa");
		btnMulta.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			if(txtValor.getText().trim().equals("")){
				JOptionPane.showMessageDialog(null, "Preencha o valor da multa!");
			}else{
				String valor = txtValor.getText();
				Double a1 = Double.parseDouble(valor.replace(",", "."));
				double a2 = Integer.parseInt(txtAtraso.getText());
				a1 *= a2;
				String r1 = "" + a1;
				txtMulta.setText("R$ "+ r1);}	
				}	
		});
		btnMulta.setBounds(353, 56, 130, 50);
		contentPane.add(btnMulta);
		
		JLabel lblDataDeReserva = new JLabel("Data de reserva:");
		lblDataDeReserva.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblDataDeReserva.setBounds(12, 135, 130, 16);
		contentPane.add(lblDataDeReserva);
		
		JLabel lblDataParaDevoluo = new JLabel("Data para devolu\u00E7\u00E3o:");
		lblDataParaDevoluo.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblDataParaDevoluo.setBounds(435, 135, 167, 22);
		contentPane.add(lblDataParaDevoluo);
		
		JLabel lblDiasEmAtraso = new JLabel("Dias em atraso:");
		lblDiasEmAtraso.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblDiasEmAtraso.setBounds(12, 185, 123, 16);
		contentPane.add(lblDiasEmAtraso);
		
		JLabel lblValorDaMulta = new JLabel("Valor da multa por dia de atraso:");
		lblValorDaMulta.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblValorDaMulta.setBounds(341, 185, 261, 22);
		contentPane.add(lblValorDaMulta);
		
		JLabel lblMultaASer = new JLabel("Multa a ser paga:");
		lblMultaASer.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblMultaASer.setBounds(12, 231, 137, 22);
		contentPane.add(lblMultaASer);
		
		txtAtraso = new JTextField();
		txtAtraso.setBounds(154, 184, 167, 22);
		contentPane.add(txtAtraso);
		txtAtraso.setColumns(10);
		
		txtReserva = new JTextField();
		txtReserva.setBounds(154, 134, 167, 22);
		contentPane.add(txtReserva);
		txtReserva.setColumns(10);
		
		txtDevolucao = new JTextField();
		txtDevolucao.setBounds(614, 134, 162, 22);
		contentPane.add(txtDevolucao);
		txtDevolucao.setColumns(10);
		
		txtValor = new JTextField();
		txtValor.setBounds(614, 185, 162, 22);
		contentPane.add(txtValor);
		txtValor.setColumns(10);
		
		txtMulta = new JTextField();
		txtMulta.setBounds(154, 233, 167, 22);
		contentPane.add(txtMulta);
		txtMulta.setColumns(10);
		
	}	
}
