package projetoStart;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;

public class CadastroBibliotecario extends JFrame {

	
	
	private JPanel contentPane;
	private JTextField txtUsuario;
	private JTextField txtSenha;
	private JTextField txtNome;
	private JTextField txtEmail;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		
		
		
		
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CadastroBibliotecario frame = new CadastroBibliotecario();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public CadastroBibliotecario() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 794, 415);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblUsuario = new JLabel("Usu�rio:");
		lblUsuario.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblUsuario.setBounds(139, 60, 65, 30);
		contentPane.add(lblUsuario);
		
		JLabel lblSenha = new JLabel("Senha:");
		lblSenha.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblSenha.setBounds(150, 120, 54, 30);
		contentPane.add(lblSenha);
		
		JLabel lblNome = new JLabel("Nome:");
		lblNome.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNome.setBounds(150, 180, 52, 30);
		contentPane.add(lblNome);
		
		JLabel lblEmail = new JLabel("Email:");
		lblEmail.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblEmail.setBounds(150, 240, 48, 30);
		contentPane.add(lblEmail);
		
		txtUsuario = new JTextField();
		txtUsuario.setFont(new Font("Tahoma", Font.PLAIN, 15));
		txtUsuario.setBounds(260, 65, 260, 22);
		contentPane.add(txtUsuario);
		txtUsuario.setColumns(10);
		
		txtSenha = new JTextField();
		txtSenha.setFont(new Font("Tahoma", Font.PLAIN, 15));
		txtSenha.setBounds(260, 125, 260, 22);
		contentPane.add(txtSenha);
		txtSenha.setColumns(10);
		
		txtNome = new JTextField();
		txtNome.setFont(new Font("Tahoma", Font.PLAIN, 15));
		txtNome.setBounds(260, 185, 260, 22);
		contentPane.add(txtNome);
		txtNome.setColumns(10);
		
		txtEmail = new JTextField();
		txtEmail.setFont(new Font("Tahoma", Font.PLAIN, 15));
		txtEmail.setBounds(260, 245, 260, 22);
		contentPane.add(txtEmail);
		txtEmail.setColumns(10);
		
		JButton btnCadastrar = new JButton("Cadastrar");
		btnCadastrar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				BancoDeDados banco = new BancoDeDados();
				banco.conectar();
				if(banco.estaConectado()){
					if(txtEmail.getText().trim().equals("")){
						JOptionPane.showMessageDialog(null, "Campo Email sem dados!");
					}else if(txtNome.getText().trim().equals("")){
						JOptionPane.showMessageDialog(null, "Campo Nome sem dados!");
					}else if(txtSenha.getText().trim().equals("")){
						JOptionPane.showMessageDialog(null, "Campo Senha sem dados!");
					}else if (txtUsuario.getText().trim().equals("")){
						JOptionPane.showMessageDialog(null, "Campo Usu�rio sem dados!");
					}else{
						banco.inserirBibliotecario(txtUsuario.getText(), txtSenha.getText(), txtEmail.getText(), txtNome.getText());
						CadastroBibliotecario.this.dispose();
					}
				}else{
					System.out.println("errou!");
				}
				banco.desconectar();
			}
		});
		btnCadastrar.setBounds(215, 307, 130, 50);
		contentPane.add(btnCadastrar);
		
		JButton btnCancelar = new JButton("Cancelar");
		btnCancelar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CadastroBibliotecario.this.dispose();
			}
		});
		btnCancelar.setBounds(456, 307, 130, 50);
		contentPane.add(btnCancelar);
		
		JLabel lblTopo = new JLabel("Digite todos os dados abaixo para efetuar o cadastro de um novo bibliotec�rio");
		lblTopo.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblTopo.setBounds(52, 13, 712, 30);
		contentPane.add(lblTopo);
	}
	
	
}
