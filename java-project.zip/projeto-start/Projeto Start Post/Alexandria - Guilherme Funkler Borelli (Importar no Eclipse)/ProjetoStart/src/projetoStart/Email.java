package projetoStart;
import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import org.apache.commons.mail.EmailException;
import org.apache.commons.mail.SimpleEmail;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import javax.swing.JTextField;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.MalformedURLException;

public class Email extends Autenticacao {

	private JPanel contentPane;
	private JTextField txtNomeDest;
	private JTextField txtAssunto;
	private JTextField txtTitulo;
	private JTextField txtSenha;
	private JTextField txtDestinatario;
	
	
	
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Email frame = new Email();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	public void sendEmail() throws EmailException {			
		   SimpleEmail email = new SimpleEmail();
		   email.setHostName("smtp.gmail.com");
		   email.setSmtpPort(465);
		   email.addTo(txtDestinatario.getText(), txtNomeDest.getText());
		   email.setFrom(retorno[3], retorno[4]);
		   email.setSubject(txtTitulo.getText());
		   email.setMsg(txtAssunto.getText());
		   email.setSSL(true);
		   email.setAuthentication(retorno[3], txtSenha.getText());
		   email.send();
		}
	
	public Email() throws EmailException {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 831, 464);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblPara = new JLabel("Nome do Destinat�rio:");
		lblPara.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblPara.setBounds(12, 14, 177, 16);
		contentPane.add(lblPara);
		
		JLabel lblAssunto = new JLabel("Assunto:");
		lblAssunto.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblAssunto.setBounds(12, 219, 69, 16);
		contentPane.add(lblAssunto);
		
		JButton btnEnviar = new JButton("Enviar");
		btnEnviar.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnEnviar.setBounds(464, 371, 97, 25);
		contentPane.add(btnEnviar);
		btnEnviar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					sendEmail();
					JOptionPane.showMessageDialog(null, "Email enviado com sucesso!");
					Email.this.dispose();
				} catch (EmailException e1) {
					e1.printStackTrace();
				}
				
				
			}
		});
		
		JButton btnDescartar = new JButton("Descartar");
		btnDescartar.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnDescartar.setBounds(633, 371, 112, 25);
		contentPane.add(btnDescartar);
		btnDescartar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Email.this.dispose();				
			}
		});
		
		txtNomeDest = new JTextField();
		txtNomeDest.setFont(new Font("Tahoma", Font.PLAIN, 15));
		txtNomeDest.setBounds(197, 12, 548, 22);
		contentPane.add(txtNomeDest);
		txtNomeDest.setColumns(10);
		
		txtAssunto = new JTextField();
		txtAssunto.setFont(new Font("Tahoma", Font.PLAIN, 15));
		txtAssunto.setBounds(93, 113, 652, 232);
		contentPane.add(txtAssunto);
		txtAssunto.setColumns(10);
		
		JLabel lblTtulo = new JLabel("T�tulo:");
		lblTtulo.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblTtulo.setBounds(12, 80, 51, 16);
		contentPane.add(lblTtulo);
		
		txtTitulo = new JTextField();
		txtTitulo.setFont(new Font("Tahoma", Font.PLAIN, 15));
		txtTitulo.setBounds(93, 78, 652, 22);
		contentPane.add(txtTitulo);
		txtTitulo.setColumns(10);
		
		JLabel lblSenhaDoEmail = new JLabel("Senha do email:");
		lblSenhaDoEmail.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblSenhaDoEmail.setBounds(12, 375, 127, 16);
		contentPane.add(lblSenhaDoEmail);
		
		txtSenha = new JTextField();
		txtSenha.setFont(new Font("Tahoma", Font.PLAIN, 15));
		txtSenha.setBounds(151, 374, 301, 22);
		contentPane.add(txtSenha);
		txtSenha.setColumns(10);
		
		txtDestinatario = new JTextField();
		txtDestinatario.setFont(new Font("Tahoma", Font.PLAIN, 15));
		txtDestinatario.setBounds(197, 46, 548, 22);
		contentPane.add(txtDestinatario);
		txtDestinatario.setColumns(10);
		
		JLabel lblEmailDoDestinatrio = new JLabel("Email do destinat�rio:");
		lblEmailDoDestinatrio.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblEmailDoDestinatrio.setBounds(12, 47, 173, 16);
		contentPane.add(lblEmailDoDestinatrio);
	}
}
