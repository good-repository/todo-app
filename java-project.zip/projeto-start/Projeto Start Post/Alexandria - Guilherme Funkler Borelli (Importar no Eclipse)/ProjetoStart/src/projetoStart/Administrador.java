package projetoStart;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Administrador extends JFrame {

	private JPanel contentPane;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				
		
				try {
					Administrador frame = new Administrador();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	
		
		
	}

	private void cadastraBibliotecario(){
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CadastroBibliotecario frame = new CadastroBibliotecario();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	};
	public void cadastraAssociado(){
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CadastroAssociado frame = new CadastroAssociado();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	};
	public void editaAssociado(){
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					EditaAssociado frame = new EditaAssociado();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	};
	public void excluiAssociado(){
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ExcluiAssociado frame = new ExcluiAssociado();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});  
	};
	private void editaBibliotecario(){
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					EditaBibliotecario frame = new EditaBibliotecario();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	};
	private void excluiBibliotecario(){
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ExcluiBibliotecario frame = new ExcluiBibliotecario();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	};
	public void consultaCadastro(){
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ConsultaCadastro frame = new ConsultaCadastro();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	};
	public void mudarFundoPrograma(){
		
	};
	
	private void cadastroAdministrador(){
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CadastroAdministrador frame = new CadastroAdministrador();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	};
	
	private void editaAdmin(){
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					EditaAdministrador frame = new EditaAdministrador();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	};
	
	private void excluiAdmin(){
		EventQueue.invokeLater(new Runnable() {
			
			public void run() {
				try{
					ExcluiAdministrador frame = new ExcluiAdministrador();
					frame.setVisible(true);
				}catch(Exception e){
					e.printStackTrace();
				}
				
			}
		});
	}
	
	public void email(){
		EventQueue.invokeLater(new Runnable() {
			
			public void run() {
				try{
					Email frame = new Email();
					frame.setVisible(true);
				}catch(Exception e){
					e.printStackTrace();
				}
				
			}
		});
	}
	
	/**
	 * Create the frame.
	 */
	public Administrador() {
		setTitle("Alexandria Gest�o de Bibliotecas V0.7 beta");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 992, 489);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Ol� administrador, selecione a a��o desejada!");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel.setBounds(313, 0, 359, 64);
		contentPane.add(lblNewLabel);
		
		JButton btnCadastraBibliotecario = new JButton("Cadastrar Bibliotec�rio(a)");
		btnCadastraBibliotecario.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cadastraBibliotecario();
			}
		});
		btnCadastraBibliotecario.setBounds(362, 77, 250, 50);
		contentPane.add(btnCadastraBibliotecario);
		
		JButton btnCadastraAssociado = new JButton("Cadastrar Associado(a)");
		btnCadastraAssociado.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				cadastraAssociado();
			}
		});
		btnCadastraAssociado.setBounds(712, 77, 250, 50);
		contentPane.add(btnCadastraAssociado);
		
		JButton btnEditaBibliotecario = new JButton("Editar Bibliotec�rio(a)");
		btnEditaBibliotecario.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				editaBibliotecario();
			}
		});
		btnEditaBibliotecario.setBounds(362, 165, 250, 50);
		contentPane.add(btnEditaBibliotecario);
		
		JButton btnEditaAssociado = new JButton("Editar Associado(a)");
		btnEditaAssociado.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				editaAssociado();
			}
		});
		btnEditaAssociado.setBounds(712, 165, 250, 50);
		contentPane.add(btnEditaAssociado);
		
		JButton btnExcluiBibliotecario = new JButton("Excluir Bibliotec�rio(a)");
		btnExcluiBibliotecario.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			excluiBibliotecario();
			}
		});
		btnExcluiBibliotecario.setBounds(362, 256, 250, 50);
		contentPane.add(btnExcluiBibliotecario);
		
		JButton btnExcluiAssociado = new JButton("Excluir Associado(a)");
		btnExcluiAssociado.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				excluiAssociado();
			}
		});
		btnExcluiAssociado.setBounds(712, 256, 250, 50);
		contentPane.add(btnExcluiAssociado);
		
		JButton btnConsultaCadastro = new JButton("Consulta ao Cadastro");
		btnConsultaCadastro.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				consultaCadastro();
			}
		});
		btnConsultaCadastro.setBounds(362, 341, 250, 50);
		contentPane.add(btnConsultaCadastro);
		
		JButton btnEscreverEmail = new JButton("Escrever E-mail");
		btnEscreverEmail.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent arg0) {
			email();
		}
	});
		btnEscreverEmail.setBounds(12, 341, 250, 50);
		contentPane.add(btnEscreverEmail);
		
		JButton btnCadastraAdm = new JButton("Cadastrar Administrador");
		btnCadastraAdm.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				cadastroAdministrador();
			}
		});
		btnCadastraAdm.setBounds(12, 80, 250, 45);
		contentPane.add(btnCadastraAdm);
		
		JButton btnEditaAdministrador = new JButton("Editar Administrador");
		btnEditaAdministrador.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				editaAdmin();
			}
		});
		btnEditaAdministrador.setBounds(12, 165, 250, 50);
		contentPane.add(btnEditaAdministrador);
		
		JButton btnExcluiAdministrador = new JButton("Excluir Administrador");
		btnExcluiAdministrador.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				excluiAdmin();		
			}
		});
		btnExcluiAdministrador.setBounds(12, 256, 250, 50);
		contentPane.add(btnExcluiAdministrador);
	}
}
